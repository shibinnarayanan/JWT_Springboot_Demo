package com.svv;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.svv.entity.User;
import com.svv.repository.UserRepository;

@SpringBootApplication
public class JwtDemo2Application {
	
	@Autowired
	UserRepository userRepo;

	public static void main(String[] args) {
		SpringApplication.run(JwtDemo2Application.class, args);
	}
	
//	@PostConstruct
//	public void init()
//	{
//		List<User> list = Arrays.asList(new User(1,"shibin","123"),new User(2,"user1","321"));
//		userRepo.saveAll(list);
//	}

}
