package com.svv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.svv.entity.User;

public interface UserRepository extends JpaRepository<User,Integer>{

	public User findUserByUsername(String Username);

}
