package com.svv.utility;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JWTUtil {
	
private String SECRET_KEY="secret";
	
	public String extractUsername(String token) {
		String extractClaim = extractClaim(token,Claims :: getSubject);
		System.out.println("ec: "+extractClaim);
		return extractClaim;
	}
	
	public Date extractExpiration(String token) {
		return extractClaim(token,Claims::getExpiration);
	}
	public <T> T extractClaim(String token, Function<Claims,T> claimsResolver){
		final Claims claims = extractAllClaims(token);
		 T apply = claimsResolver.apply(claims);
		 System.out.println("TTTT: "+apply);
		 return apply;
	}
	private Claims extractAllClaims(String token) {
		Claims body = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
		System.out.println(body.getId());
		System.out.println(body.getSubject());
		System.out.println(body.getIssuer());
		System.out.println(body.getIssuedAt());
		System.out.println(body.getAudience());
		System.out.println(body.getExpiration());
		return body;
	}
	private Boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}
	public String generateToken(UserDetails userDetails) {
		Map<String,Object> claims = new HashMap<>();
		return createToken(claims, userDetails.getUsername());
	}
	public String createToken(Map<String,Object> claims, String subject) {
		return Jwts
		.builder()
		.setClaims(claims)
		.setSubject(subject)
		.setIssuedAt(new Date(System.currentTimeMillis()))
		.setExpiration(new Date(System.currentTimeMillis()+TimeUnit.HOURS.toMillis(1)))
		.signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
	}
	public Boolean validateToken(String token, UserDetails userDetails) {
		final String username = extractUsername(token);
		System.out.println("vt: "+username);
		return (username.equals(userDetails.getUsername())&& !isTokenExpired(token));
	}

}
