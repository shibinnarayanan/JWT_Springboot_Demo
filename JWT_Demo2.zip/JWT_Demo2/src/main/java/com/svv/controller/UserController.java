package com.svv.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.svv.entity.AuthReq;
import com.svv.utility.JWTUtil;

@RestController
public class UserController {
	
	@Autowired
	private JWTUtil jwtUtil;
	
	@Autowired
	private AuthenticationManager authMangr;
	
	@GetMapping("/")
	public String welcome()
	{
		System.out.println("inside welcome method");
		return "hi, welcome";
	}
	
	@GetMapping("/greeting")
	public String greeting()
	{
		System.out.println("inside welcome method");
		return "hi, good morning";
	}
	
	
	@PostMapping("/authenticate")
	public String generateTocken(@RequestBody AuthReq authReq) throws Exception
	{
		
		try {
			authMangr.authenticate(new UsernamePasswordAuthenticationToken(authReq.getUsername(), authReq.getPassword()));
		} catch (Exception e) {
			throw new Exception("Invalid username and password");
		}
		
		return jwtUtil.generateToken(new User(authReq.getUsername(), authReq.getPassword(), new ArrayList<>()));
		
	}

}
